package <%= appPackage %>.data.repository.api

open class ApiClient(val api: Api) : Api 