package <%= appPackage %>.ui.home

import <%= appPackage %>.base.ui.BaseState

data class HomeState(val int: Int) : BaseState()