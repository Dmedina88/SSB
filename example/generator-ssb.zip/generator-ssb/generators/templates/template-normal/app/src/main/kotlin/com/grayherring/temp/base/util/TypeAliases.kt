package <%= appPackage %>.base.util

import <%= appPackage %>.base.events.Event
import <%= appPackage %>.base.ui.BaseState

typealias EventState = Pair<Event, BaseState>