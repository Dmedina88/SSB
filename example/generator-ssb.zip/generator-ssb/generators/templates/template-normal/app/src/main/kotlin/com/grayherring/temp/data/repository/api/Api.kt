package <%= appPackage %>.data.repository.api

interface Api {}

