package <%= appPackage %>.mock

import <%= appPackage %>.data.repository.api.Api


class MockAPI : Api